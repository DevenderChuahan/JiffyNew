package `in`.jiffycharge.gopower.model


data class Order_Details_model(
    val item: Item,
    val success: Boolean
)