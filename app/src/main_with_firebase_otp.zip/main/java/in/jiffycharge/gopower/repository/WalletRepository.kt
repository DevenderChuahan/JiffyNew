package `in`.jiffycharge.gopower.repository

import `in`.jiffycharge.gopower.Network.ApiInterface
import `in`.jiffycharge.gopower.model.User_balance_model
import `in`.jiffycharge.gopower.model.Wallet_history_model
import `in`.jiffycharge.gopower.viewmodel.WalletViewModel
import androidx.lifecycle.MutableLiveData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException

class WalletRepository(private val api:ApiInterface) {

    val balance_data=MutableLiveData<User_balance_model>()
    val wallet_history_data=MutableLiveData<Wallet_history_model>()
    val response_message=MutableLiveData<String>()

    init {
        fetch_user_balance()
        fetch_wallet_history()

    }


    private fun fetch_user_balance() {
        CoroutineScope(Dispatchers.IO).launch {
            val response=api.get_user_balance()

            withContext(Dispatchers.Main)
            {

                try {

                    if (response.isSuccessful)
                    {

                        response_message.postValue(response.code().toString())
                        balance_data.postValue(response.body())


                    }else
                    {
                        response_message.postValue(response.code().toString())


                    }


                }catch (e:HttpException)
                {
                    e.printStackTrace()
                }catch (e:Throwable)
                {
                    e.printStackTrace()
                }


            }


        }


    }

    private fun fetch_wallet_history() {
        CoroutineScope(Dispatchers.IO).launch {
            val response=api.get_wallet_history()

            withContext(Dispatchers.Main)
            {

                try {

                    if (response.isSuccessful)
                    {

                        response_message.postValue(response.code().toString())
                        wallet_history_data.postValue(response.body())


                    }else
                    {
                        response_message.postValue(response.code().toString())


                    }


                }catch (e:HttpException)
                {
                    e.printStackTrace()
                }catch (e:Throwable)
                {
                    e.printStackTrace()
                }


            }


        }
    }



}