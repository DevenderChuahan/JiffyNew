package `in`.jiffycharge.gopower.view.map

interface Home_Interface {
    fun log_out()
    fun open_drawer()
    fun open_profile()
    fun go_to_Home()
    fun go_to_subscription()
    fun go_to_my_orders()
    fun go_to_wallet()
    fun go_to_coupons()
    fun go_to_support()


}