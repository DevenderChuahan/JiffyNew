package `in`.jiffycharge.gopower.model

data class signup_mobile_model(
       val error: String,
    val error_description: String,
    val success: Boolean)

