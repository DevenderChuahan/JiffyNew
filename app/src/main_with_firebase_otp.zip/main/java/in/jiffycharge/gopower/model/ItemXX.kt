package `in`.jiffycharge.gopower.model

data class ItemXX(
    val authStatus: String,
    val authStep: Int,
    val balance: Int,
    val currency: String,
    val deposit: Int,
    val integral: Int,
    val inviteCode: String,
    val isBindFasebook: Boolean,
    val isBindMobile: Boolean,
    val isBindQQ: Boolean,
    val isBindWeixin: Boolean,
    val isPayBasicCost: Boolean,
    val isVIP: Boolean,
    val mobile: String,
    val nickname: String,
    val rewardAmount: Int,
    val status: String
)