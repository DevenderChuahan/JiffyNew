package `in`.jiffycharge.gopower.view.orders

interface Order_Interface {
fun Click_item(list: HashMap<String, String>)

}