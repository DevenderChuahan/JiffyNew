package `in`.jiffycharge.gopower.repository

import `in`.jiffycharge.gopower.Network.ApiInterface
import `in`.jiffycharge.gopower.model.Find_Near_Shop_Location_Model
import `in`.jiffycharge.gopower.model.User_balance_model
import androidx.lifecycle.MutableLiveData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.math.BigDecimal

class MapRepository(val api: ApiInterface) {

    val location_data= MutableLiveData<Find_Near_Shop_Location_Model>()
    val response_message=MutableLiveData<String>()



    public fun find_near_location_shop_list(lat: Double?, lng: Double?) {

        CoroutineScope(Dispatchers.IO).launch {
            val response=api.get_near_shop_location(BigDecimal(lat!!), BigDecimal(lng!!), BigDecimal(5000))

            withContext(Dispatchers.Main)
            {

                try {

                    if (response.isSuccessful)
                    {

                        response_message.postValue(response.code().toString())
                        location_data.postValue(response.body())


                    }else
                    {
                        response_message.postValue(response.code().toString())


                    }


                }catch (e: HttpException)
                {
                    e.printStackTrace()
                }catch (e:Throwable)
                {
                    e.printStackTrace()
                }


            }


        }


    }


}