package `in`.jiffycharge.gopower.view.profile


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import `in`.jiffycharge.gopower.R
import `in`.jiffycharge.gopower.databinding.FragmentOrderBinding
import `in`.jiffycharge.gopower.databinding.FragmentProfileBinding
import `in`.jiffycharge.gopower.viewmodel.HomeActivityViewModel
import `in`.jiffycharge.gopower.viewmodel.Orders_view_model
import android.app.Activity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.fragment_profile.*
import kotlinx.android.synthetic.main.nav_header_home.*
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * A simple [Fragment] subclass.
 */
class ProfileFragment : Fragment() {
    lateinit var context: Activity
    val home_view_model by viewModel<HomeActivityViewModel>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        context = requireContext() as Activity

        val bind= DataBindingUtil.inflate<FragmentProfileBinding>(inflater,R.layout.fragment_profile,container,false)
            .apply {
                this.setLifecycleOwner(this@ProfileFragment)
                this.profielVmodel = home_view_model
            }

        return  bind.root

        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_profile, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        home_view_model.repo.response_message.observe(viewLifecycleOwner,
            Observer {

                if(it.equals("200"))
                {

                    home_view_model.repo._data.observe(viewLifecycleOwner, Observer {profile_data->
                        context.runOnUiThread {


                            tv_name.setText(profile_data.item.nickname)
                            tv_email.setText("")
                            tv_cont_no.setText(profile_data.item.mobile)
                            img_profile_pic.setImageURI(null)


                            if(profile_data.item.isVIP)
                            {
                                ll_gold_user.visibility=View.VISIBLE
                            }else
                            {
                                ll_gold_user.visibility=View.GONE

                            }

                        }
                    })

                }else

                {
                    tv_name.setText("")
            tv_email.setText("")
            tv_cont_no.setText("")
            img_profile_pic.setImageURI(null)
                    ll_gold_user.visibility=View.GONE



                }
            })


//
//        if(FirebaseAuth.getInstance().currentUser!=null)
//        {
//
////            tv_name.setText("")
////            tv_email.setText("")
////            tv_cont_no.setText(FirebaseAuth.getInstance().currentUser!!.phoneNumber)
////            img_profile_pic.setImageURI(null)
//
//
//
//        }

        profile_back.setOnClickListener {
            context.onBackPressed()
        }

    }

}


