package `in`.jiffycharge.gopower.repository

import `in`.jiffycharge.gopower.Network.ApiInterface
import `in`.jiffycharge.gopower.model.Order_list_model
import `in`.jiffycharge.gopower.model.UserProfileModel
import androidx.lifecycle.MutableLiveData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException

class HomeRepository(val api:ApiInterface) {
    val _data= MutableLiveData<UserProfileModel>()
    val response_message=MutableLiveData<String>()


    init {
        fetchUserprofile()
    }

    private fun fetchUserprofile() {
        CoroutineScope(Dispatchers.IO).launch {
            val response=api.get_User_Profile()
            withContext(Dispatchers.Main)
            {
                try {

                    if (response.isSuccessful)
                    {
                        response_message.postValue(response.code().toString())
                        _data.postValue(response.body())

                    }else

                    {
                        response_message.postValue(response.code().toString())



                    }

                }catch (e: HttpException)
                {
                    e.printStackTrace()

                }catch (e:Throwable)
                {
                    e.printStackTrace()

                }
            }




        }


    }

}