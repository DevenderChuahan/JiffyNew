package `in`.jiffycharge.gopower.model

data class UserProfileModel(
    val item: ItemXX,
    val success: Boolean
)