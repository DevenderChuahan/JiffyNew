package `in`.jiffycharge.gopower.Network

import `in`.jiffycharge.gopower.model.*
import com.google.gson.JsonObject
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.*
import java.math.BigDecimal

interface ApiInterface {

            // sign_up user using  mobile no
    @POST("member/registered")
    @FormUrlEncoded
    fun sign_Up(@Field("countryCode") countryCode: String?,
                @Field("mobile") mobile: String?,
                @Field("verifycode") verifycode: String?,
                @Field("password") password: String?
                ):Call<signup_mobile_model>

   // login user using third party
    @POST("member/third_party_login")
    @FormUrlEncoded
    fun login_via_third_party(@Field("openId") openId: String?,
                @Field("accessToken") accessToken: String?,
                @Field("third_party_type") third_party_type: String?,
                @Field("clientId") clientId: String?
                ):Call<Third_party_login_model>


 // Order List api
    @POST("order/list")
    @FormUrlEncoded
    suspend fun get_order_list(@Field("ltTime") ltTime: String?):Response<Order_list_model>

// Order details api
    @GET("order/profile")
    suspend fun get_order_details(@Query("orderCode") orderCode: String?):Response<Order_Details_model>


// User Balance  api
    @GET("money/user_balance")
    suspend fun get_user_balance():Response<User_balance_model>


// User wallet History  api
    @GET("money/money_log_list")
    suspend fun get_wallet_history():Response<Wallet_history_model>

// User Profile  api
    @GET("member/userprofile")
    suspend fun get_User_Profile():Response<UserProfileModel>


// Nearest Shop Location  api
    @GET("seller/find_by_location")
    suspend fun get_near_shop_location(@Query("x") x:BigDecimal,@Query("y") y:BigDecimal,@Query("distance") distance:BigDecimal):Response<Find_Near_Shop_Location_Model>




}