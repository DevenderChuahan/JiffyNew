package `in`.jiffycharge.gopower.view.login

interface LoginInterface {
    fun Start()
    fun onfailed(message:String)
    fun onSuccess()
}