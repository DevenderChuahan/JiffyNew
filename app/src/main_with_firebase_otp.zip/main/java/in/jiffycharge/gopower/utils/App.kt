package `in`.jiffycharge.gopower.utils

import `in`.jiffycharge.gopower.di.*
import `in`.jiffycharge.gopower.repository.MapRepository
import android.app.Application
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import org.koin.core.module.Module

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@App)
            modules(netModule)
            modules(retrofitServiceModule)
            modules(orderViewModel)
            modules(order_repo_module)
            modules(wallet_view_model)
            modules(wallet_repository)
            modules(HomeViewModel)
            modules(Home_repository)
            modules(MapViewModel)
            modules(Map_repository)


        }
    }


}