package `in`.jiffycharge.gopower.model

data class ItemX(
    val availableBalance: Int,
    val currency: String
)