package `in`.jiffycharge.gopower.view.map

import android.view.View

interface MapInterface {
    fun locate_to_location()
    fun click_on_Scan()

}