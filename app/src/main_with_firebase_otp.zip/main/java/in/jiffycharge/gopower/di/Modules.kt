package `in`.jiffycharge.gopower.di

import `in`.jiffycharge.gopower.Network.ApiInterface
import `in`.jiffycharge.gopower.getsp
import `in`.jiffycharge.gopower.repository.HomeRepository
import `in`.jiffycharge.gopower.repository.MapRepository
import `in`.jiffycharge.gopower.repository.OrderRepository
import `in`.jiffycharge.gopower.repository.WalletRepository
import `in`.jiffycharge.gopower.viewmodel.HomeActivityViewModel
import `in`.jiffycharge.gopower.viewmodel.MapFragmentViewModel
import `in`.jiffycharge.gopower.viewmodel.Orders_view_model
import `in`.jiffycharge.gopower.viewmodel.WalletViewModel
import android.app.Application
import android.content.Context
import android.util.Log
import com.google.gson.FieldNamingPolicy
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import okhttp3.Cache
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import org.koin.android.ext.koin.androidApplication
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

val netModule = module {

    fun provideCache(application: Application): Cache {
        val cacheSize = 10 * 1024 * 1024
        return Cache(application.cacheDir, cacheSize.toLong())

    }

    fun provideOntercepter(context:Context):Interceptor {

        return authInterceptor(context)
    }

    fun provideHttpClient(cache: Cache, intercepter:Interceptor): OkHttpClient {
        val okhttpclientBuilder = OkHttpClient.Builder().cache(cache).addInterceptor(intercepter)
        return okhttpclientBuilder.build()


    }


    fun provideGson(): Gson {
        return GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).create()
    }

    fun provideRetrofit(factory: Gson, client: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://api.jiffycharge.in/api/")
            .addConverterFactory(GsonConverterFactory.create(factory))
            .client(client)
            .build()
    }

    single { provideCache(androidApplication()) }
    single { provideOntercepter(androidContext()) }
    single { provideHttpClient(get(),get()) }
    single { provideGson() }
    single { provideRetrofit(get(), get()) }


}
val order_repo_module= module {
    factory { OrderRepository(get()) }


}
val wallet_repository= module {

    factory { WalletRepository(get()) }
}

val wallet_view_model= module {
    factory { WalletViewModel(get()) }

}


val retrofitServiceModule= module {
    fun provideApiService(retrofit: Retrofit):ApiInterface
    {
        return retrofit.create(ApiInterface::class.java)
    }
    single { provideApiService(get()) }
}

val orderViewModel= module {
    viewModel { Orders_view_model(get()) }

}

val HomeViewModel= module {
    viewModel { HomeActivityViewModel(get()) }

}
val Home_repository= module {

    factory { HomeRepository(get()) }


}
val MapViewModel= module {
    viewModel { MapFragmentViewModel(get()) }

}
val Map_repository= module {

    factory { MapRepository(get()) }
}



class authInterceptor(val context: Context) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val requestBuilder = chain.request().newBuilder()

        // If token has been saved, add it to the request
        context.getsp("token","").let {
//            val credentials = Credentials.basic("ODYtMTg2ODIzMTAwMTU=", "MTIzNDU2")

//            requestBuilder.addHeader("Authorization", "$credentials ")
            requestBuilder.addHeader("Authorization", "Bearer $it")
//            requestBuilder.addHeader("Authorization", "$it")

                .addHeader("Content-Type", "application/json")
                .addHeader("Accept", "application/json;versions=1")

        }

        return chain.proceed(requestBuilder.build())
    }
}
