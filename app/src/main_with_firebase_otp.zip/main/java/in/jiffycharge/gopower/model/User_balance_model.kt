package `in`.jiffycharge.gopower.model


data class User_balance_model(
    val item: ItemX,
    val success: Boolean
)