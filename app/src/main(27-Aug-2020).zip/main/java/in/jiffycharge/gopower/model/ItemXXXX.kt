package `in`.jiffycharge.gopower.model

data class ItemXXXX(
    val currency: String,
    val deposit: Int
)