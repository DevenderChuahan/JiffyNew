package `in`.jiffycharge.gopower.model

data class OtpModel(
    val success: Boolean,
    val error: String,
    val error_description: String
)