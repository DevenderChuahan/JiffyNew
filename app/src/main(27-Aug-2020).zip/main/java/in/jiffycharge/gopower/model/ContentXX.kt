package `in`.jiffycharge.gopower.model

data class ContentXX(
    val amount: Int,
    val createTime: String,
    val currency: String,
    val type: String
)