package `in`.jiffycharge.gopower.model

data class FondyPaymetBO(
    val payUrl: String
)