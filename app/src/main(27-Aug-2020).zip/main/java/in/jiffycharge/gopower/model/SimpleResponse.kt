package `in`.jiffycharge.gopower.model

data class SimpleResponse(
    val error: String,
    val error_description: String,
    val success: Boolean
)