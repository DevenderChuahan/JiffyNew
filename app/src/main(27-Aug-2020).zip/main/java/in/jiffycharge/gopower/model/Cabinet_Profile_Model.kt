package `in`.jiffycharge.gopower.model

data class Cabinet_Profile_Model(
    val error: String,
    val error_description: String,
    val item: ItemXXXXXX,
    val success: Boolean
)