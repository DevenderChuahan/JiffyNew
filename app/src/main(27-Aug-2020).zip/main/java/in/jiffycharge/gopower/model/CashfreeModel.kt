package `in`.jiffycharge.gopower.model

data class CashfreeModel(
    val error: String,
    val error_description: String,
    val item: ItemXXXXX,
    val success: Boolean
)