package `in`.jiffycharge.gopower.view.walletpay

import `in`.jiffycharge.gopower.databinding.WalletpayadapterlayoutBinding
import `in`.jiffycharge.gopower.model.Wallet_history_model
import `in`.jiffycharge.gopower.view.wallet.Wallet_adapter
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class WalletPayAdapter():RecyclerView.Adapter<WalletPayAdapter.MyViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WalletPayAdapter.MyViewHolder {
val inflater=LayoutInflater.from(parent.context)
        val binding=WalletpayadapterlayoutBinding.inflate(inflater)
        return MyViewHolder(binding)



    }

    override fun getItemCount(): Int {
//        return list.content.size
        return 5

    }
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun onBindViewHolder(holder: WalletPayAdapter.MyViewHolder, position: Int) {

    }


    class MyViewHolder(val bindimg:WalletpayadapterlayoutBinding):RecyclerView.ViewHolder(bindimg.root) {


    }


}