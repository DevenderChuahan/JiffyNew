package `in`.jiffycharge.gopower.model

data class CreateOrderModel(
    val error: String,
    val error_description: String,
    val item: ItemXXXXXXX,
    val success: Boolean
)