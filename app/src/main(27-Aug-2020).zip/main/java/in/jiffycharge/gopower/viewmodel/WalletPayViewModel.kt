package `in`.jiffycharge.gopower.viewmodel

import `in`.jiffycharge.gopower.repository.WalletPayRepository
import androidx.lifecycle.ViewModel

class WalletPayViewModel(val walletPayRepo:WalletPayRepository):ViewModel() {
}