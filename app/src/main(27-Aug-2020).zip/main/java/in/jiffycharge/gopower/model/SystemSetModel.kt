package `in`.jiffycharge.gopower.model

data class SystemSetModel(
    val error: String,
    val error_description: String,
    val item: ItemXXXXXXXXXX,
    val success: Boolean
)