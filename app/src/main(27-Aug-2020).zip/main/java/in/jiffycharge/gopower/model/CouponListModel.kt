package `in`.jiffycharge.gopower.model

data class CouponListModel(
    val error: String,
    val error_description: String,
    val items: List<ItemXXXXXXXXX>,
    val success: Boolean
)