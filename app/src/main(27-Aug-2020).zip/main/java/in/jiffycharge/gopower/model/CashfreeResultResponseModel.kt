package `in`.jiffycharge.gopower.model

data class CashfreeResultResponseModel(
    val error: String,
    val error_description: String,
    val success: Boolean
)