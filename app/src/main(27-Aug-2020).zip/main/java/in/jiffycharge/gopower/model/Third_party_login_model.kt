package `in`.jiffycharge.gopower.model

data class Third_party_login_model(
    val error: String,
    val error_description: String,
    val item: String,
    val success: Boolean
)