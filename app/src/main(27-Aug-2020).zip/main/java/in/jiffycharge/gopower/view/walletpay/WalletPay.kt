package `in`.jiffycharge.gopower.view.walletpay
import `in`.jiffycharge.gopower.R
import `in`.jiffycharge.gopower.databinding.FragmentWalletBinding
import `in`.jiffycharge.gopower.viewmodel.WalletPayViewModel
import `in`.jiffycharge.gopower.viewmodel.WalletViewModel
import android.app.Activity
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import org.koin.androidx.viewmodel.ext.android.viewModel

class WalletPay : Fragment() {
    private val Wallet_Pay_View_Model by viewModel<WalletPayViewModel>()
    lateinit var context: Activity
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        context = requireContext() as Activity
        val bind = DataBindingUtil.inflate<FragmentWalletBinding>(
            inflater,
            R.layout.fragment_pay_wallet,
            container,
            false
        )
            .apply {
                this.setLifecycleOwner(this@WalletPay)
            }
        return bind.root

        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_pay_wallet, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }

}