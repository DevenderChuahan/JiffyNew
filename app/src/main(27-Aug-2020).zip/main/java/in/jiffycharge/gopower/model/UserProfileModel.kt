package `in`.jiffycharge.gopower.model

data class UserProfileModel(
    val error: String,
    val error_description: String,
    val item: ItemXX,
    val success: Boolean
)