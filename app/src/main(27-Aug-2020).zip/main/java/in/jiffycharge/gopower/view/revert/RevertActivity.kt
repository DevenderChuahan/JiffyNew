package `in`.jiffycharge.gopower.view.revert

import `in`.jiffycharge.gopower.R
import `in`.jiffycharge.gopower.model.ItemXXXXXXXX
import `in`.jiffycharge.gopower.payment.PayResultActivity
import `in`.jiffycharge.gopower.utils.Resourse
import `in`.jiffycharge.gopower.utils.getCountTimeByLong
import `in`.jiffycharge.gopower.utils.toast
import `in`.jiffycharge.gopower.view.map.MapFragment
import `in`.jiffycharge.gopower.viewmodel.HomeActivityViewModel
import android.annotation.SuppressLint
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_revert.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.util.*

class RevertActivity : AppCompatActivity() {

    val home_view_model by viewModel<HomeActivityViewModel>()
    var context: Context? = null
    private var needPay: Double = 0.0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_revert)
        val intent = intent
        if (intent != null) {
            val apiOrderBO = intent.extras?.get("apiOrderBO")
            setData(apiOrderBO as ItemXXXXXXXX)
        }
        context = this

        home_view_model.repo.payDeposit("cashfree", PayResultActivity.RETURN_URL_DEPOSIT)
        home_view_model.repo._datapayment.observe(this,
            androidx.lifecycle.Observer {
                when (it.status) {
                    Resourse.Status.LOADING -> {

                    }
                    Resourse.Status.SUCCESS -> {

                        PayResultActivity(this).checkPayResult(
                            it.data!!
                        )
                        {
                            if (it) {


                            }

                        }


                    }
                    Resourse.Status.ERROR -> {
                        toast(it.data?.error_description.toString())


                    }


                }


            })

        getcoupponListandAppSetData()


    }

    @SuppressLint("SetTextI18n")
    private fun setData(apiOrderBO: ItemXXXXXXXX) {
        val usetime = apiOrderBO.finishTime - apiOrderBO.beginTime
        orderTv.text = apiOrderBO.orderCode
        totalFeeTv.text =
            "Total Fee:${apiOrderBO.payPrice}${apiOrderBO.currency}\n${getCountTimeByLong(
                usetime,
                true
            )}"

        needPay = apiOrderBO.payPrice
        needPayTv.text = "Pay${apiOrderBO.payPrice}${apiOrderBO.currency}"
        couponTv.text = "Coupons\n0${apiOrderBO.currency}"


    }

    override fun onResume() {
        super.onResume()
        getcoupponListandAppSetData()
    }

    private fun getcoupponListandAppSetData() {

        //Coupon Api
        home_view_model.repo.getCouponList()
        home_view_model.repo.couponListResult.observe(this, androidx.lifecycle.Observer {
            runOnUiThread {

                when (it.status) {
                    Resourse.Status.LOADING -> {

                    }

                    Resourse.Status.SUCCESS -> {
                        val item = it.data!!.items
                        if (item.isEmpty()) {
                            coupns_tv.text = "no offer available"

                        } else {

                            coupns_tv.text = "${item.count()}"


                        }


                    }
                    Resourse.Status.ERROR -> {
                        coupns_tv.text = "no offer available"

                    }


                }


            }


        })


        //systemset api
        home_view_model.repo.getSystemSet()
        home_view_model.repo.systemsetResult.observe(this, androidx.lifecycle.Observer {

            runOnUiThread {

                when (it.status) {
                    Resourse.Status.LOADING -> {

                    }

                    Resourse.Status.SUCCESS -> {


                    }
                    Resourse.Status.ERROR -> {
                        toast(it.data!!.error_description)

                    }


                }

            }


        })


    }
}