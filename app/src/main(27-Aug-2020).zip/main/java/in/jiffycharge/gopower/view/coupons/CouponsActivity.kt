package `in`.jiffycharge.gopower.view.coupons

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_coupons.*
import `in`.jiffycharge.gopower.R

class CouponsActivity : AppCompatActivity() {
    val map_list=HashMap<String,String>()
    var context:Context?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coupons)
        context=this

        rv_coupon.adapter= CouponsAdapter(context!!,map_list)

    }

    override fun onBackPressed() {
        super.onBackPressed()
    }


    fun coupon_onBack(view: View) {
        onBackPressed()

    }
}
