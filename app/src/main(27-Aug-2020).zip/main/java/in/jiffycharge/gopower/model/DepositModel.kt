package `in`.jiffycharge.gopower.model

data class DepositModel(
    val error: String,
    val error_description: String,
    val item: ItemXXXX,
    val success: Boolean
)