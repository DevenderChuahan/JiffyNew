package `in`.jiffycharge.gopower.model

data class DoingInfoModel(
    val error: String,
    val error_description: String,
    val item: ItemXXXXXXXX,
    val success: Boolean
)