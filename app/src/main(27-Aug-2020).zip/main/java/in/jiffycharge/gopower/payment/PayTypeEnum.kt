package `in`.jiffycharge.gopower.payment

enum class PayTypeEnum{cashfree,Stripe}